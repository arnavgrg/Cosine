from distutils.core import setup

setup(
    name='tools',
    version='1',
    packages=['tools'],
)
